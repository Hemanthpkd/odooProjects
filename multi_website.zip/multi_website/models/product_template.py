# models/product_template.py
from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    multi_website_ids = fields.Many2many(
        'website',
        string="Visible on Websites",
        help="Leave empty = visible on ALL websites. Select one or more to restrict.",
    )

    website_id = fields.Many2one(
        'website',
        compute='_compute_website_id',
        store=True,
        readonly=False,
        string="Website",
    )

    # website_published = fields.Boolean(
    #     compute='_compute_website_published',
    #     store=True,
    # )

    @api.depends('multi_website_ids')
    def _compute_website_id(self):
        """Sync Odoo's original website_id field:
        - If exactly one website is selected → assign it
        - If zero or multiple websites → set website_id = False
        """
        for product in self:
            if len(product.multi_website_ids) == 1:
                product.website_id = product.multi_website_ids[0]
            else:
                product.website_id = False

    @api.depends('multi_website_ids', 'sale_ok')
    @api.depends_context('website_id')
    def _compute_website_published(self):
        """Determine if the product should be published on the current website:
        - Visible everywhere if no websites selected
        - Otherwise only if current website is in multi_website_ids
        - Also requires sale_ok to be True
        """
        current_website = self.env['website'].get_current_website()
        current_id = current_website.id if current_website else False

        for product in self:
            if not product.multi_website_ids:
                allowed = True
            elif current_id and current_id in product.multi_website_ids.ids:
                allowed = True
            else:
                allowed = False
            product.website_published = allowed and product.sale_ok

    # def _is_visible_on_current_website(self):
    #     print('loadsssss')
    #     """Runtime visibility check:
    #     Return True if this product should be shown on the current website.
    #     """
    #     self.ensure_one()
    #     print('loadsssss')
    #     current = self.env['website'].get_current_website()
    #     if not current:
    #         return False
    #     if not self.multi_website_ids:
    #         print('loadsssss')
    #         return True
    #     return current.id in self.multi_website_ids.ids

    def can_access_from_current_website(self):
        print('restrict')
        """Restrict direct URL access:
        Block product page access if current website is not allowed.
        """
        self.ensure_one()
        if not self.website_id and self.multi_website_ids:
            current = self.env['website'].get_current_website()
            return not current or current.id in self.multi_website_ids.ids
        return super().can_access_from_current_website()
