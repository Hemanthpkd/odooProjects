from odoo import models, fields

class ProductMultiWebsiteWizard(models.TransientModel):
    _name = 'product.multi.website.wizard'
    _description = 'Assign Multiple Websites to Products'

    website_ids = fields.Many2many(
        'website',
        string='Websites'
    )

    def action_update_websites(self):
        """Bulk-assign selected websites to the chosen products:
        - Reads active_ids from context (products selected in list view)
        - Replaces their multi_website_ids with the wizard's website_ids
        - Closes the wizard and shows a success message
        """
        active_ids = self.env.context.get('active_ids', [])
        products = self.env['product.template'].browse(active_ids)

        if products:
            products.write({'multi_website_ids': [(6, 0, self.website_ids.ids)]})

        return {
            'type': 'ir.actions.act_window_close',
            'infos': {
                'message': f"Websites updated for {len(products)} product(s).",
                'type': 'success',
            }
        }
