# models/website.py
from odoo import models, api
from odoo.osv import expression

class Website(models.Model):
    _inherit = 'website'

    @api.model
    def sale_product_domain(self):
        """Extend the product search domain for the shop page:
        - Show products with no website restriction
        - OR products whose multi_website_ids contain the current website
        Ensures /shop, categories, and search only list products allowed for the active website.
        """
        domain = super().sale_product_domain()
        website = self.get_current_website()
        if not website:
            return domain

        restrict_domain = [
            '|',
            ('multi_website_ids', '=', False),
            ('multi_website_ids', 'in', website.id),
        ]
        return expression.AND([domain, restrict_domain])
