{
    'name': 'multi website',
    'description': 'multi website',
    'category': 'All',
    'version': '19.0.1.0',
    'author': 'Hemanth N',
    'license': 'LGPL-3',
    'category': 'multi website',
    'depends': ['base', 'website', 'website_sale', 'mail', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_template.xml',
        'views/product_template_actions.xml',
        'views/confirm_popup_view.xml',


        
    ],
    'assets': {
        'point_of_sale._assets_pos': [
        
        ]
    },
    'application': True,
}