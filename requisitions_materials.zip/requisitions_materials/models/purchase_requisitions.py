# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import AccessError, UserError
from collections import defaultdict


class PurchaseRequisitions(models.Model):
    _name = "purchase.requisitions"
    _description = "Purchase Requisitions"

    name = fields.Char(
        string="Requisition Reference", required=True, copy=False, readonly=True,
        index=True, default=lambda self: _('New'),
        help="Unique number for this requisition, generated automatically."
    )
    employee_id = fields.Many2one(
        'hr.employee', string="Employee", required=True,
        default=lambda self: self.env.user.employee_id.id,
        help="Employee making the requisition (automatically set to logged-in user)"
    )
    department_id = fields.Many2one('hr.department', string="Department", required=True)
    company_id = fields.Many2one('res.company', string="Company", required=True, default=lambda self: self.env.company)
    requisition_date = fields.Date(string="Requisition Date", default=fields.Date.today)
    received_date = fields.Date(string="Received Date")
    analytic_account_id = fields.Many2one('account.analytic.account', string="Requisition Deadline Analytic Account")
    requisition_responsible_id = fields.Many2one(
        'res.users', string="Requisition Responsible",
        compute="_compute_requisition_responsible", store=False
    )
    requisition_line_ids = fields.One2many('purchase.requisitions.line', 'requisition_id', string="Requisition Lines")
    destination_location_id = fields.Many2one(
        'stock.location', string="Destination Location",
        compute='_compute_destination_location', store=True
    )
    state = fields.Selection([
        ('new', 'New'),
        ('waiting_department_approval', 'Waiting Department Approval'),
        ('waiting_ir_approved', 'Waiting IR Approved'),
        ('purchase_order_created', 'Purchase Order Created'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
        ('received', 'Received'),
    ], string="State", default='new', required=True)

    requisition_officer_state = fields.Selection([
        ('waiting_for_approval', 'Waiting for Approval'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
    ], string="State", default='waiting_for_approval', required=True)

    department_manager_state = fields.Selection([
        ('waiting_for_approval', 'Waiting for Approval'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
    ], string="State", default='waiting_for_approval', required=True)

    purchase_order_count = fields.Integer(string="Purchase Orders", compute="_compute_purchase_order_count", store=False)
    internal_picking_count = fields.Integer(string="Internal Pickings", compute="_compute_internal_picking_count", store=False)
    source_location_id = fields.Many2one('stock.location', string="Source Location", compute='_compute_source_location', store=False)
    picking_type = fields.Many2one('stock.picking.type', string="Picking Type")

    @api.model
    def create(self, vals_list):
        """Create requisition with auto-sequence and default employee/company."""
        if isinstance(vals_list, dict):
            vals_list = [vals_list]
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('purchase.requisitions') or _('New')
            if not vals.get('company_id'):
                vals['company_id'] = self.env.company.id
            if not vals.get('employee_id'):
                if self.env.user.employee_id:
                    vals['employee_id'] = self.env.user.employee_id.id
                else:
                    raise UserError(_("The current user is not linked to an employee. Please contact your administrator."))
        return super(PurchaseRequisitions, self).create(vals_list)

    # def write(self, vals):
    #     """Restrict editing certain fields after creation."""
    #     if 'employee_id' in vals:
    #         raise UserError(_("You cannot change the employee after the requisition is created."))
    #     return super(PurchaseRequisitions, self).write(vals)

    @api.depends('employee_id')
    def _compute_destination_location(self):
        """Compute destination location based on employee settings."""
        for record in self:
            record.destination_location_id = record.employee_id.destination_location

    def _sum_available_internal_qty(self, product):
        """Return total available internal stock quantity for a product."""
        domain = [
            ('product_id', '=', product.id),
            ('location_id.usage', '=', 'internal'),
            ('quantity', '>', 0),
        ]
        quants = self.env['stock.quant'].search(domain)
        return sum(quants.mapped('quantity'))

    def _get_source_locations_for_qty(self, product, qty):
        """Get internal locations and quantities to fulfill required stock."""
        if qty <= 0:
            return []
        domain = [
            ('product_id', '=', product.id),
            ('location_id.usage', '=', 'internal'),
            ('quantity', '>', 0),
        ]
        quants = self.env['stock.quant'].search(domain, order='quantity desc')
        remaining = qty
        result = []
        for q in quants:
            take = min(q.quantity, remaining)
            result.append((q.location_id, take))
            remaining -= take
            if remaining <= 0:
                break
        return result if remaining <= 0 else []

    def action_submit(self):
        """Submit the requisition for department approval (employee action)."""
        for record in self:
            if not record.picking_type:
                raise UserError(_("Please select a Picking Type before submitting the requisition."))

            # Loop through all lines to validate both cases
            for line in record.requisition_line_ids:

                # INTERNAL TRANSFER: Only check stock
                if line.requisition_action == 'internal_transfer':

                    total_available = self._sum_available_internal_qty(line.product_id)
                    if total_available < line.quantity:
                        raise UserError(_(
                            "The required quantity (%(qty)s) of product '%(product)s' is not available in internal stock.\n"
                            "Only %(available)s is available across all warehouses.\n\n"
                            "Please reduce the quantity or change the action to 'Purchase Order'."
                        ) % {
                            'qty': line.quantity,
                            'product': line.product_id.display_name,
                            'available': total_available
                        })

                # PURCHASE ORDER:
                elif line.requisition_action == 'purchase_order':
                    # vendor_ids is required *via XML*, so you don't need Python check
                    pass

            # Final state check
            if record.state != 'new':
                raise AccessError(_("You can only submit new requisitions."))

            record.state = 'waiting_department_approval'

        return True

    def action_approve(self):
        """Approve the requisition (manager action)."""
        for record in self:
            if record.state != 'waiting_department_approval':
                raise AccessError("You can only approve requisitions waiting for department approval.")

            # Move to next state
            record.state = 'waiting_ir_approved'
            record.department_manager_state='approved'

            # Send email to Requisition Officer
            print('email',record.requisition_responsible_id.email)
            if record.requisition_responsible_id:
                template = self.env.ref('requisitions_materials.approve_to_ir_template')

                # SAFE WAY: do NOT write on the template
                email_values = {
                    'email_to': record.requisition_responsible_id.email,
                }

                template.send_mail(record.id, force_send=True, email_values=email_values)

            else:
                raise UserError("No Requisition Officer found. Please assign a user to the Requisition Officer group.")

        return True

    def action_decline(self):
        """Decline requisition at department manager level."""
        for record in self:
            if record.state != 'waiting_department_approval':
                raise AccessError("You can only decline requisitions waiting for department approval.")
            record.state = 'declined'
            record.department_manager_state = 'declined'
        return True

    def action_ir_approve(self):
        """Approve requisition by IR officer and create PO or internal transfer."""
        for record in self:
            if record.state != 'waiting_ir_approved':
                raise AccessError("You can only approve requisitions waiting for IR approval.")
            if record.company_id not in self.env.user.company_ids:
                raise AccessError(f"You do not have access to company '{record.company_id.name}'.")
            if not record.picking_type:
                raise UserError(_("Please select a Picking Type before IR approval."))

            po_lines = record.requisition_line_ids.filtered(lambda l: l.requisition_action == 'purchase_order')
            transfer_lines = record.requisition_line_ids.filtered(lambda l: l.requisition_action == 'internal_transfer')
            handled_po = False

            # === PURCHASE ORDERS (unchanged) ===
            if po_lines:
                purchase_picking_type = self.with_company(record.company_id).env['stock.picking.type'].search([
                    ('code', '=', 'incoming'),
                    ('warehouse_id.company_id', '=', record.company_id.id)
                ], limit=1)
                if not purchase_picking_type:
                    raise UserError(f"No incoming picking type configured for company '{record.company_id.name}'.")

                vendor_lines = defaultdict(list)
                for line in po_lines:
                    for vendor in line.vendor_ids:
                        vendor_lines[vendor.id].append(line)

                created_pos = self.env['purchase.order']
                for vendor_id, lines in vendor_lines.items():
                    order_lines = []
                    for line in lines:
                        order_lines.append((0, 0, {
                            'product_id': line.product_id.id,
                            'name': line.description or line.product_id.name,
                            'product_qty': line.quantity,
                            'product_uom_id': line.uom_id.id,
                            'price_unit': line.product_id.with_company(record.company_id).standard_price,
                            'requisition_line_id': line.id,
                        }))
                    po_vals = {
                        'company_id': record.company_id.id,
                        'partner_id': vendor_id,
                        'origin': record.name,
                        'picking_type_id': purchase_picking_type.id,
                        'requisition_id': record.id,
                        'order_line': order_lines,
                    }
                    po = self.with_company(record.company_id).env['purchase.order'].create(po_vals)
                    created_pos |= po

                if created_pos:
                    created_pos.with_company(record.company_id).button_confirm()
                    handled_po = True

            # === INTERNAL TRANSFERS – FIXED FOR ODOO 19 ===
            if transfer_lines:
                picking_type_to_use = record.picking_type
                destination_location = record.employee_id.destination_location
                if not destination_location:
                    raise UserError("Destination location not set for the employee.")

                for line in transfer_lines:
                    sources = self._get_source_locations_for_qty(line.product_id, line.quantity)
                    if not sources:
                        raise UserError(_("Not enough internal stock for %s (required: %s)") % 
                                        (line.product_id.display_name, line.quantity))

                    for source_loc, qty_to_take in sources:
                        move = self.env['stock.move'].create({
                            'product_id': line.product_id.id,
                            'product_uom_qty': qty_to_take,
                            'product_uom': line.uom_id.id,
                            'location_id': source_loc.id,
                            'location_dest_id': destination_location.id,
                            'picking_type_id': picking_type_to_use.id,
                            'description_picking': line.description or line.product_id.display_name,
                        })

                        picking = self.env['stock.picking'].create({
                            'origin': record.name,
                            'picking_type_id': picking_type_to_use.id,
                            'location_id': source_loc.id,
                            'location_dest_id': destination_location.id,
                            'move_ids': [(6, 0, [move.id])],  # Correct command
                        })

                        # Force correct locations (overrides picking type defaults)
                        picking.write({
                            'location_id': source_loc.id,
                            'location_dest_id': destination_location.id,
                        })

                        picking.action_confirm()
                        try:
                            picking.action_assign()
                        except Exception:
                            pass

            # Update state
            record.state = 'purchase_order_created' if handled_po else 'approved'
            record.requisition_officer_state = 'approved'

        return True

    def action_ir_decline(self):
        """Decline requisition at IR officer level."""
        for record in self:
            if record.state != 'waiting_ir_approved':
                raise AccessError("You can only decline requisitions waiting for IR approval.")
            record.state = 'declined'
            record.requisition_officer_state = 'declined'
        return True

    @api.depends('requisition_line_ids')
    def _compute_purchase_order_count(self):
        """Compute number of purchase orders linked to the requisition."""
        for record in self:
            record.purchase_order_count = self.env['purchase.order'].search_count([('requisition_id', '=', record.id)])

    @api.depends('name')
    def _compute_internal_picking_count(self):
        """Compute number of internal pickings linked to the requisition."""
        for record in self:
            domain = [('origin', '=', record.name)]
            if record.picking_type:
                domain.append(('picking_type_id', '=', record.picking_type.id))
            record.internal_picking_count = self.env['stock.picking'].search_count(domain)

    def action_view_purchase_orders(self):
        """Open purchase orders related to the requisition."""
        self.ensure_one()
        return {
            'name': _('Purchase Orders'),
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.order',
            'view_mode': 'list,form',
            'domain': [('requisition_id', '=', self.id)],
            'context': "{'create': False}",
            'target': 'current',
        }

    def action_view_internal_pickings(self):
        """Open internal pickings created from the requisition."""
        self.ensure_one()
        domain = [('origin', '=', self.name)]
        if self.picking_type:
            domain.append(('picking_type_id', '=', self.picking_type.id))
        return {
            'name': _('Pickings'),
            'type': 'ir.actions.act_window',
            'res_model': 'stock.picking',
            'view_mode': 'list,form',
            'domain': domain,
            'context': {'create': False},
            'target': 'current',
        }

    @api.depends('state')
    def _compute_source_location(self):
        """Determine source location from related pickings."""
        for record in self:
            if record.state in ['received', 'purchase_order_created', 'approved']:
                internal_picking = self.env['stock.picking'].search([('origin', '=', record.name)], limit=1)
                if internal_picking:
                    record.source_location_id = internal_picking.location_id
                else:
                    po_picking = self.env['stock.picking'].search([('purchase_id.requisition_id', '=', record.id)], limit=1)
                    record.source_location_id = po_picking.location_id if po_picking else False
            else:
                record.source_location_id = False

    @api.depends()
    def _compute_requisition_responsible(self):
        """Assign the default requisition officer from the user group."""
        group = self.env.ref("requisitions_materials.user_group_requisition_officer", raise_if_not_found=False)
        if not group:
            return
        self.env.cr.execute("SELECT uid FROM res_groups_users_rel WHERE gid = %s LIMIT 1", (group.id,))
        result = self.env.cr.fetchone()
        for rec in self:
            rec.requisition_responsible_id = result[0] if result else False


# Keep your existing PurchaseOrder and StockPicking inherits (they are correct)
class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def _prepare_stock_moves(self, picking):
        """Set destination location on stock moves based on requisition."""
        moves = super()._prepare_stock_moves(picking)
        requisition = self.requisition_id
        if requisition and requisition.destination_location_id:
            for move in moves:
                move['location_dest_id'] = requisition.destination_location_id.id
        return moves

    def button_confirm(self):
        """Confirm PO and update destination location for related pickings."""
        result = super().button_confirm()
        for order in self:
            if order.requisition_id and order.requisition_id.destination_location_id:
                for picking in order.picking_ids:
                    picking.location_dest_id = order.requisition_id.destination_location_id.id
                    for move in picking.move_ids:
                        move.location_dest_id = order.requisition_id.destination_location_id.id
        return result


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        """Validate picking and update requisition state after completion."""
        print('self',self)
        for picking in self:
            if (picking.picking_type_id.code == 'incoming' and
                picking.purchase_id and picking.purchase_id.requisition_id and
                picking.purchase_id.requisition_id.destination_location_id):
                dest_loc = picking.purchase_id.requisition_id.destination_location_id
                picking.location_dest_id = dest_loc.id
                for move in picking.move_ids:
                    move.location_dest_id = dest_loc.id

        res = super(StockPicking, self).button_validate()

        requisitions_to_check = self.env['purchase.requisitions']
        for picking in self:
            requisition = False
            if picking.picking_type_id.code == 'incoming' and picking.purchase_id:
                requisition = picking.purchase_id.requisition_id
            elif picking.origin:
                requisition = self.env['purchase.requisitions'].search([('name', '=', picking.origin)], limit=1)
            if requisition and requisition.state not in ('received', 'cancel', 'declined'):
                requisitions_to_check |= requisition

        for req in requisitions_to_check:
            incoming_pickings = self.env['stock.picking'].search([
                ('purchase_id.requisition_id', '=', req.id),
                ('picking_type_id.code', '=', 'incoming'),
                ('state', 'not in', ('draft', 'cancel'))
            ])
            internal_pickings = self.env['stock.picking'].search([
                ('origin', '=', req.name),
                ('state', 'not in', ('draft', 'cancel'))
            ])
            incoming_done = not incoming_pickings or all(p.state == 'done' for p in incoming_pickings)
            internal_done = not internal_pickings or all(p.state == 'done' for p in internal_pickings)
            if incoming_done and internal_done:
                req.write({'state': 'received', 'received_date': fields.Date.today()})

        return res