from odoo import fields, models

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    destination_location = fields.Many2one(
        'stock.location',  
        string="Destination Location",  
        help="Location where the requested materials will be delivered",
    )
