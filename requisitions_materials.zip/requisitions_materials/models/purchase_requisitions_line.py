from odoo import fields, models, api

class PurchaseRequisitionsLine(models.Model):
    _name = "purchase.requisitions.line"
    _description = "Purchase Requisition Line"

    requisition_id = fields.Many2one('purchase.requisitions', string="Requisition", required=True)
    requisition_action = fields.Selection([
        ('purchase_order', 'Purchase Order'),
        ('internal_transfer', 'Internal Transfer')
    ], string="Requisition Action", required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    description = fields.Text(string="Description")
    quantity = fields.Float(string="Quantity", required=True)
    uom_id = fields.Many2one(
        'uom.uom',
        string="Unit of Measure",
        required=True,
        default=lambda self: self.env.ref('uom.product_uom_unit').id
    )
    vendor_ids = fields.Many2many('res.partner', string="Vendors", domain="[('supplier', '=', True)]")
