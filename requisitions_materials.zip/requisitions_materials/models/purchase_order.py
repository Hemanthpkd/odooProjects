from odoo import fields, models


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    requisition_id = fields.Many2one('purchase.requisitions', string="Requisition Reference")


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    requisition_line_id = fields.Many2one('purchase.requisitions.line', string="Requisition Line")



