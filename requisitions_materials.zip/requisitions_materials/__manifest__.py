{
    'name': 'requisitions material ',
    'description': 'requisitions material ',
    'category': 'All',
    'version': '19.0.1.0',
    'author': 'Hemanth N',
    'license': 'LGPL-3',
    'category': 'Requisitions Management',
    'depends': ['base', 'hr', 'purchase', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/ir_sequence_data.xml',
        'security/security_groups.xml',
        'security/ir_rule_only_employee.xml',
        'data/ir_module_category_data.xml',
        'data/requisition_officer_mail_template.xml',
        'views/destination_location.xml',
        'views/purchase_requisitions.xml',
        'views/requistions_materials_menu.xml',
        
    ],
    'assets': {
        'point_of_sale._assets_pos': [
        
        ]
    },
    'application': True,
}