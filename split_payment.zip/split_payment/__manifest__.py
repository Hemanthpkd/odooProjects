{
    'name': 'split payment ',
    'description': 'split payment',
    'category': 'All',
    'version': '19.0.1.0',
    'author': 'Hemanth N',
    'license': 'LGPL-3',
    'category': 'split payment',
    'depends': ['base', 'point_of_sale'],
        
    'data': [
         
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'split_payment/static/src/js/split_button.js',
            'split_payment/static/src/xml/split_button.xml',
            'split_payment/static/src/xml/order_receipt.xml',
        ]
    },
    'application': True,
}