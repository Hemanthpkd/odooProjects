/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { NumberPopup } from "@point_of_sale/app/components/popups/number_popup/number_popup";
import { SelectionPopup } from "@point_of_sale/app/components/popups/selection_popup/selection_popup";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { _t } from "@web/core/l10n/translation";


patch(PosStore.prototype, {
    async splitOrder() {

        const currentOrder = this.getOrder();
        if (!currentOrder) {
            this.dialog.add(AlertDialog, {
                title: _t("Error"),
                body: _t("No active order found. Please add items to cart first."),
            });
            return;
        }

        const orderTotal = currentOrder.getTotalWithTax();
        if (orderTotal <= 0) {
            this.dialog.add(AlertDialog, {
                title: _t("Error"),
                body: _t("Order total must be greater than zero to split payment"),
            });
            return;
        }

        // Step 1: Ask for number of splits
        const splitResult = await makeAwaitable(this.dialog, NumberPopup, {
            title: _t("Split Payment - Enter Number of Parts"),
            startingValue: 2,
        });

        if (!splitResult) {
            return;
        }

        const splits = parseInt(splitResult);
        if (splits < 2) {
            this.dialog.add(AlertDialog, {
                title: _t("Error"),
                body: _t("Please enter a value greater than 1"),
            });
            return;
        }

        // Get available payment methods
        const paymentMethods = this.config.payment_method_ids || [];
        if (!paymentMethods || paymentMethods.length === 0) {
            this.dialog.add(AlertDialog, {
                title: _t("Error"),
                body: _t("No payment methods available. Please configure payment methods in POS settings."),
            });
            return;
        }

        // Build popup list
        const paymentList = paymentMethods.map(pm => ({
            id: pm.id,
            label: pm.name,
            item: pm,
        }));

        // Calculate per-split amount
        const splitAmount = orderTotal / splits;

        // Step 2: Ask user to choose methods
        const selectedMethods = [];
        for (let i = 1; i <= splits; i++) {
            const formattedAmount = this.env.utils.formatCurrency(splitAmount);

            const result = await makeAwaitable(this.dialog, SelectionPopup, {
                title: _t(`Split ${i-1}/${splits} - Select Payment Method (${formattedAmount})`),
                list: paymentList,
            });

            let selectedId;
            if (typeof result === 'object' && result !== null) {
                selectedId = result.id;
            } else {
                selectedId = result;
            }

            if (!selectedId) {
                this.notification.add(
                    _t(`Split payment cancelled at part ${i}`),
                    { type: "warning" }
                );
                return;
            }

            const selectedMethod = paymentMethods.find(pm => pm.id === selectedId);
            if (!selectedMethod) {
                this.dialog.add(AlertDialog, {
                    title: _t("Error"),
                    body: _t("Selected payment method not found."),
                });
                return;
            }

            selectedMethods.push(selectedMethod);
        }

        // Step 3: Clear existing payment lines
        const existingLines = currentOrder.payment_ids ? [...currentOrder.payment_ids] : [];
        for (const line of existingLines) {
            try {
                currentOrder.removePaymentline(line);
            } catch (_) {}
        }

        // Step 4: Create split payment lines
        let successCount = 0;
        for (let i = 0; i < splits; i++) {
            const paymentMethod = selectedMethods[i];
            const amount = i === splits - 1
                ? orderTotal - (splitAmount * (splits - 1))
                : splitAmount;

            try {
                const paymentLine = currentOrder.addPaymentline(paymentMethod);
                if (paymentLine) {
                    paymentLine.setAmount(amount);
                    paymentLine._isSplitPayment = true;
                    successCount++;
                }
            } catch (_) {}
        }

        const totalPaid = currentOrder.payment_ids.reduce((sum, pl) => sum + pl.amount, 0);
        const roundingDifference = orderTotal - totalPaid;

        if (Math.abs(roundingDifference) > 0.0001) {
            const roundingMethod = selectedMethods[selectedMethods.length - 1];
            const roundingLine = currentOrder.addPaymentline(roundingMethod);

            if (roundingLine) {
                roundingLine.setAmount(roundingDifference);
                roundingLine._isSplitPayment = true;
            }
        }

        // Step 6: Notify
        if (successCount === splits) {
            this.notification.add(
                _t(`Order split into ${splits} payments: ${selectedMethods.map(m => m.name).join(', ')}`),
                { type: "success" }
            );
        } else {
            this.notification.add(
                _t(`Warning: Only ${successCount} of ${splits} payment lines were created`),
                { type: "warning" }
            );
        }
    },

    hasSplitPayments() {
        return (
            this.currentOrder?.payment_ids?.some(pl => pl._isSplitPayment) ||
            false
        );
    },
});
